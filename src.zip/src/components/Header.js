import React from 'react';
import './Header.css';

const Header = (props) => {
  return (
    <header className="App-header">
      <nav className='App-header_right'>
        <h3>LOGO</h3>
      </nav>
      <div className='app-header_center'>
       <a href="#home">Home</a>
        <a href="#about">About</a>
        <a href="#contact">Contact</a>
       </div>
      <div className="logo">{props.name} Blog</div>
    </header>
  );
};

export default Header;