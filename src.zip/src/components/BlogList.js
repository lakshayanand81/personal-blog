import React, { useState } from 'react';
import './BlogList.css';

const posts = [
  {
    id: 1,
    title: 'First Blog Post',
    content: 'This is the content of the first blog post.',
  },
  {
    id: 2,
    title: 'Second Blog Post',
    content: 'This is the content of the second blog post.',
  },
  {
    id: 3,
    title: 'Third Blog Post',
    content: 'This is the content of the third blog post.',
  },
];

const BlogList = () => {
  const [likes, setLikes] = useState(Array(posts.length).fill(0));

  const handleLike = (postId) => {
    const updatedLikes = [...likes];
    updatedLikes[postId - 1] += 1; // Assuming ids start from 1
    setLikes(updatedLikes);
  };

  return (
    <div className="BlogList">
      {posts.map((post, index) => (
        <div key={post.id} className="BlogPost">
          <h2>{post.title}</h2>
          <p>{post.content}</p>
          <button onClick={() => handleLike(post.id)}>Like ({likes[index]})</button>
        </div>
      ))}
    </div>
  );
};

export default BlogList;
