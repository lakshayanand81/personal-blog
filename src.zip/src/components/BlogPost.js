import React, { Component } from 'react';
import './BlogPost.css';

class BlogPost extends Component {
  render() {
    const { title, content } = this.props;
    return (
      <div className="BlogPost">
        <h2>{title}</h2>
        <p>{content}</p>
      </div>
    );
  }
}

export default BlogPost;
