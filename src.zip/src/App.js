
import React, { useState } from 'react';
import Navbar from './Navbar';
import Parent from './Parent';
import './App.css';

const App = () => {
    const [count, setCount] = useState(0);

    return (
        <div className="app-container">
            <Navbar userName="Laksh Blog" />
            <main className="main-content">
                <h1>Welcome to Laksh's Blog</h1>
                <p>This is a simple blog application built with React.</p>
                <img src="https://via.placeholder.com/300x200.png?text=Image+1" alt="Image 1" className="blog-image" />
                <img src="https://via.placeholder.com/300x200.png?text=Image+2" alt="Image 2" className="blog-image" />
                <Parent />
                <div className="counter-section">
                    <p>Count: {count}</p>
                    <button className="tap-button" onClick={() => setCount(count + 1)}>Tap to Increment</button>
                </div>
            </main>
        </div>
    );
}

export default App;
